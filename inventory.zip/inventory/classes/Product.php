<?php
class Product {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        return $this->conn->query("SELECT * FROM products");
    }

    public function create($name, $category, $stock, $price) {
        if ($stock < 0) return "Stok tidak boleh negatif!";

        $this->conn->query("
            INSERT INTO products (name, category, stock, price)
            VALUES ('$name','$category','$stock','$price')
        ");

        return "Berhasil tambah";
    }

    public function reduceStock($id, $qty) {
        $data = $this->conn->query("SELECT stock FROM products WHERE id=$id")->fetch_assoc();

        if ($qty > $data['stock']) return "Stok tidak cukup!";

        $newStock = $data['stock'] - $qty;
        $this->conn->query("UPDATE products SET stock=$newStock WHERE id=$id");

        if ($newStock < 5) return "⚠️ Stok Menipis!";
        return "Transaksi berhasil";
    }
}
?>
