<?php
class Transaction {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($product_id, $qty) {
        $this->conn->query("
            INSERT INTO transcantions (product_id, quantity)
            VALUES ('$product_id','$qty')
        ");
    }

    public function getAll() {
        return $this->conn->query("
            SELECT t.*, p.name 
            FROM transcantions t
            JOIN products p ON t.product_id = p.id
        ");
    }
}
?>