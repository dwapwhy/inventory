<?php
include "../config/database.php";
include "../classes/product.php";
include "../classes/transactions.php";

$db = (new Database())->connect();

$product = new Product($db);
$transaction = new Transaction($db);

if ($_POST) {
    echo $product->reduceStock($_POST['product_id'], $_POST['qty']);
    $transaction->create($_POST['product_id'], $_POST['qty']);
}

$products = $product->getAll();
?>

<form method="POST">
<select name="product_id">
<?php while($p = $products->fetch_assoc()): ?>
<option value="<?= $p['id'] ?>">
<?= $p['name'] ?> (<?= $p['stock'] ?>)
</option>
<?php endwhile; ?>
</select>

<input type="number" name="qty">
<button>Transaksi</button>
</form>