<?php
include "../config/database.php";
include "../classes/Product.php";

$db = (new Database())->connect();
$product = new Product($db);

if ($_POST) {
    echo $product->create(
        $_POST['name'],
        $_POST['category'],
        $_POST['stock'],
        $_POST['price']
    );
}
?>

<form method="POST">
Nama: <input name="name"><br>
Kategori:
<select name="category">
<option>Laptop</option>
<option>Smartphone</option>
</select><br>
Stok: <input type="number" name="stock"><br>
Harga: <input type="number" name="price"><br>
<button>Tambah</button>
</form>