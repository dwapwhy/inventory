<?php
include "../config/database.php";
include "../classes/Product.php";
include "../classes/Transaction.php";

$db = (new Database())->connect();

$product = new Product($db);
$transaction = new Transaction($db);

$products = $product->getAll();
$transactions = $transaction->getAll();
?>

<h2>Produk</h2>
<?php while($p = $products->fetch_assoc()): ?>
<p><?= $p['name'] ?> - <?= $p['stock'] ?></p>
<?php endwhile; ?>

<h2>Transaksi</h2>
<?php while($t = $transactions->fetch_assoc()): ?>
<p><?= $t['name'] ?> - <?= $t['quantity'] ?></p>
<?php endwhile; ?>