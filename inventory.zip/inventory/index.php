<h2>Menu</h2>
<a href="pages/add_product.php">Tambah Produk</a><br>
<a href="pages/transaction.php">Transaksi</a><br>
<a href="pages/dashboard.php">Dashboard</a>